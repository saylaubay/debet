<?php


namespace App\Repostirories\Interfaces;


interface KrudInterface
{

    public function getOne();
    public function getAll();
    public function ashiw();
    public function oqiw();
    public function janalaw();
    public function oshiriw();

}
