<?php


namespace App\Repostirories\Interfaces;


interface RuleRepositoryInterface
{

}
