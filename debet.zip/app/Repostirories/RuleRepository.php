<?php


namespace App\Repostirories;


use App\Repostirories\Interfaces\RuleRepositoryInterface;

class RuleRepository implements RuleRepositoryInterface
{

}
