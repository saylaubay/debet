<?php


namespace App\Services;


class RuleService extends BaseService
{

}
